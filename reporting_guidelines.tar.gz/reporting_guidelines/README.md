# Reporting Guidelines

This repository contains reporting guidelines checklists for various research methodologies, converted from PDF to Markdown format.

## Contents

### PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses)
- [PRISMA 2020 Checklist](checklists/prisma/PRISMA_2020_checklist-ab3g.md)
- [PRISMA 2020 Expanded Checklist](checklists/prisma/PRISMA_2020_expanded_checklist-rp3l.md)

### STROBE (Strengthening the Reporting of Observational Studies in Epidemiology)
- [STROBE Checklist](checklists/strobe/STROBE_checklist.md)

### RECORD (REporting of studies Conducted using Observational Routinely-collected Data)
- [RECORD Checklist](checklists/record/RECORD_checklist.md)

### TRIPOD+AI (Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis + Artificial Intelligence)
- [TRIPOD+AI Checklist](checklists/tripod_ai/TRIPODAI_checklist.md)

## Sources
- PRISMA: https://www.prisma-statement.org/
- STROBE: https://www.strobe-statement.org/
- RECORD: https://www.record-statement.org/
- TRIPOD+AI: https://www.tripod-statement.org/

## License
These checklists are distributed under the licenses specified by their original creators. Please refer to the original sources for license information.
