# TRIPOD+AI Checklist

Source: https://www.tripod-statement.org/

## Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis + Artificial Intelligence

TRIPOD+AI is an extension of the TRIPOD Statement, addressing the unique challenges of AI in biomedical and healthcare applications.

```
Section/Topic | Item | Checklist Item
--------------|------|---------------
Title and abstract | 1 | Identify the study as developing, validating, or updating a prediction model, the target population, and the outcome to be predicted.
 | 1a | Specify that AI/ML methods were used to develop, validate, or update the model.
 | 1b | Provide a summary of objectives, study design, setting, participants, sample size, predictors, outcome, statistical analysis, results, and conclusions.
Introduction | 2 | Explain the medical context and rationale for developing or validating the prediction model.
 | 2a | Describe the intended use, target users, and healthcare settings for the model.
 | 3 | Specify the study objectives, including whether the study describes the development of a model, validation of an existing model, or both.
Methods | 4 | Describe the study design or source of data, setting, and key study dates.
 | 4a | Specify the data sources used for model development and validation.
 | 5 | Specify key elements of the study setting, including number and location of centers.
 | 5a | Describe how the AI/ML model was integrated into the existing workflow.
 | 6 | Clearly define the outcome that is predicted by the model, including how and when assessed.
 | 6a | Report any actions taken to blind assessment of the outcome to be predicted.
 | 7 | Clearly define all predictors used in developing or validating the model.
 | 7a | Report how the AI/ML model represents and processes the input data.
 | 8 | Describe how data were handled, including missing data and data transformations.
 | 9 | Describe how the study size was arrived at.
 | 10 | Describe how predictors were handled in the analyses.
 | 10a | Specify the approach to predictor selection and handling of model overfitting.
 | 11 | Specify the type of model, all model-building procedures, and methods for validation.
 | 11a | Specify the AI/ML modeling architecture, including hyperparameters and their optimization.
 | 11b | Describe the interpretability or explainability approaches used.
 | 12 | Specify all measures used to assess model performance and, if relevant, to compare models.
 | 12a | Report performance metrics appropriate for the AI/ML approach used.
 | 13 | Describe methods for assessing model calibration and discrimination.
 | 14 | Describe methods for model updating or adaptation, if done.
 | 14a | Describe methods for model updating or adaptation over time.
Results | 15 | Report the number of participants and outcomes in each phase of the study.
 | 15a | Report the characteristics of the development and validation datasets.
 | 16 | Report the number of participants with missing data for predictors and outcome.
 | 16a | Report how missing data were handled.
 | 17 | Report results of model performance, including calibration and discrimination.
 | 17a | Report performance metrics with confidence intervals.
 | 18 | Report any model updating or adaptation, if done.
 | 18a | Report how the model performs across different subgroups and settings.
Discussion | 19 | Discuss the model's strengths, limitations, and potential applications.
 | 19a | Discuss the implications of using AI/ML in the specific clinical context.
 | 20 | Provide an overall interpretation of the results considering objectives, limitations, and related studies.
 | 20a | Discuss potential biases, generalizability, and clinical applicability of the model.
Other information | 21 | Provide information about model availability and access.
 | 21a | Provide the model's specifications, including version and environment requirements.
 | 22 | Give the source of funding and the role of the funders for the study.
 | 22a | Report any conflicts of interest related to the development or validation of the model.
```
